gtk-theme-menda & gtk-theme-menda-dark
======================================

Manjaro's official GTK themes, based on Vertex by horst3180.
Also includes Metacity, Xfwm, Cinnamon and Gnome Shell themes.

Name: Menda

Summary: A light and dark theme with a mix of green and light/dark grey colors.

URL: http://manjaro.org

Licensed as GPLv3.

Dependencies: gtk-engine-murrine

The Menda theme includes:
- GTK2 theme
- GTK3 theme
- Gnome shell
- Cinnamon Theme
- Metacity theme
- Xfwm4 theme
- Openbox Theme

