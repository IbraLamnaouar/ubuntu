
### Icon Request

Please provide the following in your request:

- Application name
- Icon=`iconname`
- Insert/attach a copy of the original icon for reference

**Providing `iconname` is mandatory.**

If you can't find the `iconname`, refer to an app's desktop file, for example: `/usr/share/applications/gimp.desktop`
